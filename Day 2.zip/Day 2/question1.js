let univ = "Amikom";

let subs = univ.substr(1, 3);
console.log(subs);

document.write(subs);