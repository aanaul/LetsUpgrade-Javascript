let countries = ["Indonesia", "India", "United Kingdom", "France", "Chech", "Saudi Arabia", "Egypt", "Swiss"].reverse();
console.log(countries);
document.write(countries);