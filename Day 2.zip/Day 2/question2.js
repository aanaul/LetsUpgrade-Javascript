let minute = 12;
let seconds = 60;

let calculate = minute * seconds;

console.log(minute + ' minutes is equal to ' + calculate + ' seconds');
document.write(minute + ' minutes is equal to ' + calculate + ' seconds');