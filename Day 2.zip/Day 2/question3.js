let home = ["window", "door", "bedroom", "living room", "bathroom", "garage"];

console.log(home[2]);
document.write(home[2]);